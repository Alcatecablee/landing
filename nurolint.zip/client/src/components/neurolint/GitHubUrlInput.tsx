// This component has been integrated into the new GitHubUpload component design
// No longer needed as a separate component
export function GitHubUrlInput() {
  return null;
}
